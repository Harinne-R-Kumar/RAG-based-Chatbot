import os
import PyPDF2
from docx import Document
import pandas as pd
import numpy as np
from sentence_transformers import SentenceTransformer
import faiss
import ollama
import moviepy
import speech_recognition as sr
import warnings
warnings.filterwarnings("ignore")

# Step 1: Extract text from different file formats
def extract_text_from_pdf(file_path):
    with open(file_path, 'rb') as file:
        reader = PyPDF2.PdfReader(file)
        text = ""
        for page in reader.pages:
            text += page.extract_text()
    return text

def extract_text_from_docx(file_path):
    doc = Document(file_path)
    text = ""
    for para in doc.paragraphs:
        text += para.text + "\n"
    return text

def extract_text_from_csv(file_path):
    df = pd.read_csv(file_path)
    text = df.to_string()
    return text

def extract_text_from_image(file_path):
    try:
        with open(file_path, "rb") as image_file:
            image_data = image_file.read()
        response = ollama.generate(
            model="llava:7b",
            prompt="Describe the content of this image in detail.",
            images=[image_data]
        )
        return response['response'].strip()
    except Exception as e:
        return f"Error processing image: {str(e)}"

def extract_text_from_video(file_path):
    try:
        video = moviepy.editor.VideoFileClip(file_path)
        audio_path = "temp_audio.wav"
        video.audio.write_audiofile(audio_path)

        recognizer = sr.Recognizer()
        with sr.AudioFile(audio_path) as source:
            audio = recognizer.record(source)
            audio_text = recognizer.recognize_google(audio)
        os.remove(audio_path)

        frame_path = "temp_frame.jpg"
        video.save_frame(frame_path, t=1.0)
        visual_text = extract_text_from_image(frame_path)
        os.remove(frame_path)
        video.close()

        return f"Audio Content: {audio_text}\nVisual Content: {visual_text}"
    except Exception as e:
        return f"Error processing video: {str(e)}"

# Step 2: Process and chunk documents based on user input
def process_documents(chunk_size=500):
    documents = []
    print("Enter the full path to each file you want to process (e.g., D:\\projects\\assignmentinternshala\\sample.pdf).")
    print("Supported formats: PDF, DOCX, CSV, JPG/PNG, MP4/AVI.")
    print("Type 'done' when you are finished adding files.")

    # Open a file to save processed data
    with open("processed_data.txt", "w", encoding="utf-8") as output_file:
        while True:
            file_path = input("Enter file path (or 'done' to finish): ").strip()
            if file_path.lower() == "done":
                break

            if not os.path.exists(file_path):
                print(f"File not found: {file_path}. Please try again.")
                continue

            filename = os.path.basename(file_path)
            if filename.endswith(".pdf"):
                text = extract_text_from_pdf(file_path)
            elif filename.endswith(".docx"):
                text = extract_text_from_docx(file_path)
            elif filename.endswith(".csv"):
                text = extract_text_from_csv(file_path)
            elif filename.endswith((".jpg", ".png")):
                text = extract_text_from_image(file_path)
            elif filename.endswith((".mp4", ".avi")):
                text = extract_text_from_video(file_path)
            else:
                print(f"Unsupported file format: {filename}. Skipping.")
                continue

            # Print the extracted text
            print(f"\n--- Processed: {filename} ---")
            print(f"Extracted Text:\n{text}\n")

            # Save the extracted text to the file
            output_file.write(f"--- File: {filename} ---\n")
            output_file.write(f"Extracted Text:\n{text}\n\n")

            documents.append({"text": text, "source": filename})

    if not documents:
        print("No valid files were provided.")
        return [], []

    chunks = []
    metadatas = []
    for doc in documents:
        text = doc["text"]
        words = text.split()
        for i in range(0, len(words), chunk_size):
            chunk = " ".join(words[i:i + chunk_size])
            chunks.append(chunk)
            metadatas.append({"source": doc["source"]})
    return chunks, metadatas

# Step 3: Build retrieval system
def build_retrieval_system(chunks, metadatas):
    embedder = SentenceTransformer('all-MiniLM-L6-v2')
    embeddings = embedder.encode(chunks, show_progress_bar=True)

    dimension = embeddings.shape[1]
    index = faiss.IndexFlatL2(dimension)
    index.add(embeddings)
    return index, embedder, chunks, metadatas

# Step 4: Retrieve relevant chunks
def retrieve_chunks(query, index, embedder, chunks, metadatas, k=3):
    query_embedding = embedder.encode([query])
    distances, indices = index.search(query_embedding, k)
    retrieved_chunks = [chunks[idx] for idx in indices[0]]
    retrieved_metadatas = [metadatas[idx] for idx in indices[0]]
    return retrieved_chunks, retrieved_metadatas

# Step 5: Generate answer using llava:7b
def generate_answer(query, retrieved_chunks):
    context = "\n".join(retrieved_chunks)
    prompt = f"Context: {context}\n\nQuestion: {query}\nAnswer:"
    
    response = ollama.generate(model="llava:7b", prompt=prompt)
    answer = response['response'].strip()
    return answer

# Main function to run the chatbot
def main():
    print("Processing documents...")
    chunks, metadatas = process_documents()
    if not chunks:
        print("No documents to process. Exiting.")
        return

    print("Building retrieval system...")
    index, embedder, chunks, metadatas = build_retrieval_system(chunks, metadatas)

    print("Chatbot is ready! Type 'exit' to quit.")
    while True:
        query = input("Enter your query: ")
        if query.lower() == "exit":
            break
        retrieved_chunks, retrieved_metadatas = retrieve_chunks(query, index, embedder, chunks, metadatas)
        answer = generate_answer(query, retrieved_chunks)
        print(f"Answer: {answer}\n")
        print("Sources:", [meta["source"] for meta in retrieved_metadatas])

if __name__ == "__main__":
    main()